from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'koopman_controller_pkg'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    
    # === Installation of Data Files ===
    # This section ensures that the necessary model, gains, and trajectory 
    # files are copied into the ROS 2 install directory under 'share/pkg_name/data'.
    data_files=[
        # Standard ROS 2 install files
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        (os.path.join('share', package_name), glob('package.xml')),
        
        # Install all .pth and .mat files found in the root of the source directory
        (os.path.join('share', package_name, 'data'), glob('*.pth')),
        (os.path.join('share', package_name, 'data'), glob('*.mat')),
    ],
    
    # === Python Dependencies ===
    install_requires=[
        'setuptools',
        'numpy',
        'scipy',
        'torch', # Required for loading and using the PyTorch model
        # Note: Your custom module 'Learn_Koopman_with_Klinear_Lerobot' 
        # is assumed to be installed implicitly by find_packages() 
        # if it's located within the 'koopman_controller_pkg' directory.
    ],
    
    zip_safe=True,
    maintainer='hojeong',
    maintainer_email='0321lovehj@gmail.com',
    description='Koopman-Affine LQR Controller for Lerobot',
    license='TODO: License declaration',
    tests_require=['pytest'],
    
    # === Entry Point for the ROS 2 Executable Node ===
    entry_points={
        'console_scripts': [
            # The format is: <executable_name> = <package_name>.<module_name>:<function_name>
            'koopman_controller = koopman_controller_pkg.lerobot_joint_isaac:main',
        ],
    },
)