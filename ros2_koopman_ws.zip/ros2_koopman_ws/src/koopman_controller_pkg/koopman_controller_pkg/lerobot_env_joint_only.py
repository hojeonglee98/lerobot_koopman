import pybullet as pb
import pybullet_data
import numpy as np
import os

class LerobotEnv(object):

    def __init__(self, render=True, ts=0.002):

        self.frame_skip = 10
        if render:
            self.client = pb.connect(pb.GUI)
        else:
            self.client = pb.connect(pb.DIRECT)

        pb.setTimeStep(ts)
        # pb.setAdditionalSearchPath(pybullet_data.getDataPath())
        # # pb.setAdditionalSearchPath(r"D:\DeepKoopmanWithControl\lerobot\lerobot_description\robots\assets")
        # planeID = pb.loadURDF('plane.urdf')

        # current_dir = os.path.dirname(os.path.abspath(__file__))
        # urdf_path = os.path.join(current_dir, 'lerobot_description', 'robots', 'so101_new_calib.urdf')
        # self.robot = pb.loadURDF(urdf_path, [0., 0., 0.], useFixedBase=1)
        # 1. Get the path to pybullet's data directory
        pybullet_data_path = pybullet_data.getDataPath()
        
        # 2. Add BOTH paths to the search directory. This is good practice.
        pb.setAdditionalSearchPath(pybullet_data_path)
        pb.setAdditionalSearchPath(r"D:\DeepKoopmanWithControl\lerobot\lerobot_description\robots\assets")
        
        # 3. Load the plane using its full, unambiguous path
        plane_path = os.path.join(pybullet_data_path, 'plane.urdf')
        planeID = pb.loadURDF(plane_path)
        
        # --- MODIFICATION END ---

        current_dir = os.path.dirname(os.path.abspath(__file__))
        urdf_path = os.path.join(current_dir, 'lerobot_description', 'robots', 'so101_new_calib.urdf')
        self.robot = pb.loadURDF(urdf_path, [0., 0., 0.], useFixedBase=1)
        pb.setGravity(0, 0, -9.81)

        # --- existing names kept ---
        self.reset_joint_state = [0., 0., 0., 0., 0.]
        self.ee_id = 5  # will be overwritten below if the proper tool link is found
        self.sat_val = 0.3
        self.joint_low  = np.array([-1.91986, -1.74533, -1.69,   -1.65806, -2.74385])
        self.joint_high = np.array([ 1.91986,  1.74533,  1.69,    1.65806,  2.84121])
        self.Nstates = 10
        self.udim = 5
        self.dt = self.frame_skip * ts

        # Prefer the actual tool frame if present (e.g., "gripper_frame_link")
        ee_by_name = self._link_index_by_name("gripper_frame_link")
        if ee_by_name is not None:
            self.ee_id = ee_by_name

        self.reset()

    # ---------- helpers (new) ----------
    def _link_index_by_name(self, name: str):
        """Return link index by its name, or None if not found."""
        for i in range(pb.getNumJoints(self.robot)):
            info = pb.getJointInfo(self.robot, i)
            link_name = info[12].decode('utf-8')
            if link_name == name:
                return i
        return None

    def _get_joint_positions(self):
        """Convenience: current joint angles as np.array, size 5."""
        return np.array([s[0] for s in pb.getJointStates(self.robot, range(5))], dtype=float)

    def get_ik(self, position, orientation=None):
        if orientation is None:
            jnts = pb.calculateInverseKinematics(self.robot, self.ee_id, position)[:5]
        else:
            jnts = pb.calculateInverseKinematics(self.robot, self.ee_id, position, orientation)[:5]
        # clip to joint limits for numerical sanity
        return np.clip(np.array(jnts, dtype=float), self.joint_low, self.joint_high)

    def get_state(self):
        jnt_st = pb.getJointStates(self.robot, range(5))
        ee_pos, ee_orn = pb.getLinkState(self.robot, self.ee_id)[-2:]

        jnt_ang = [j[0] for j in jnt_st]
        jnt_vel = [j[1] for j in jnt_st]

        self.state = np.concatenate([ee_pos, ee_orn, jnt_ang, jnt_vel])
        return self.state.copy()

    def reset(self):
        for i, q in enumerate(self.reset_joint_state):
            pb.resetJointState(self.robot, i, float(q))
        return self.get_state()

    def reset_state(self, joint):
        for i, q in enumerate(joint):
            pb.resetJointState(self.robot, i, float(q))
        return self.get_state()

    def step(self, action):
        a = np.clip(action, -self.sat_val, self.sat_val)
        pb.setJointMotorControlArray(
            self.robot, range(5),
            pb.VELOCITY_CONTROL,
            targetVelocities=a
        )
        for _ in range(self.frame_skip):
            pb.stepSimulation()
        return self.get_state()
    
    # def step(self, action):
    #     a = np.clip(action, -self.sat_val, self.sat_val)
    #     pb.setJointMotorControlArray(
    #         self.robot, range(5),
    #         pb.TORQUE_CONTROL,
    #         forces=a
    #     )
    #     for _ in range(self.frame_skip):
    #         pb.stepSimulation()
    #     return self.get_state()

    # ---------- optional convenience (new) ----------
    def step_to_ik(self, position, orientation=None, kp=1.0):
        """
        Convenience: IK -> joint positions -> convert to joint velocities -> step().
        Keeps everything consistent with VELOCITY_CONTROL.
        """
        q_des = self.get_ik(position, orientation)
        q_now = self._get_joint_positions()
        v_cmd = kp * (q_des - q_now) / self.dt
        return self.step(v_cmd)
