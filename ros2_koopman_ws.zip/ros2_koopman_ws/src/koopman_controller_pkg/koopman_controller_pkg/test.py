import numpy as np
from scipy.io import loadmat

mat_data = loadmat('/home/hojeong/ros2_koopman_ws/src/koopman_controller_pkg/koopman_controller_pkg/Kopt.mat')
# mat_data = loadmat('/home/hojeong/DeepKoopmanWithControl/lerobot_joint_only/ee_trajectories.mat')

# 2. Inspect the keys (variable names)
print("Variables found in the .mat file (dictionary keys):")
print(mat_data.keys())

print(mat_data['Kopt'].shape)