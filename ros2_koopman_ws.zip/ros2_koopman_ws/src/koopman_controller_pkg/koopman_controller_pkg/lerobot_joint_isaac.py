import rclpy
from rclpy.node import Node
import numpy as np
import torch
import torch.nn as nn 
from scipy.io import loadmat
import os
from ament_index_python.packages import get_package_share_directory
from sensor_msgs.msg import JointState      

# Assuming this module is installed in your package directory
from koopman_controller_pkg import Learn_Koopman_with_Klinear_Lerobot as lka


class KoopmanLQRController(Node):
    """
    ROS 2 Node implementing the Koopman-Affine LQR controller with a fixed-rate timer.
    """
    def __init__(self):
        super().__init__('koopman_lqr_controller')
        self.get_logger().info('Koopman LQR Node Initializing...')

        # --- 1. Model Loading (Sets self.ts = 0.02) ---
        self._load_koopman_model()

        # --- 2. Trajectory Data ---
        self._load_desired_trajectory()
        self.current_timestep = 0 # Simple counter for tracking trajectory reference
        self.N_JOINTS = 5

        # Define the names of the 5 controlled joints (MUST match your URDF)
        self.JOINT_NAMES = [
            'shoulder_pan', 
            'shoulder_lift', 
            'elbow_flex',
            'wrist_flex', 
            'wrist_roll'
        ]
        
        # --- NEW: State Storage for Timer Loop ---
        self.latest_state_msg = None 

        # --- TIMER SETUP: Create timer using self.ts, but CANCEL it immediately ---
        # self.ts is now defined in _load_koopman_model
        self.timer = self.create_timer(self.ts, self.control_loop) 
        self.timer.cancel() # Critical: Prevents V command from starting too early

        # --- 3. ROS 2 Communication Setup ---
        # Publishers (must be defined first for _set_initial_position)
        self.position_publisher = self.create_publisher(
            JointState,
            '/joint_command', 
            1
        )

        self.velocity_publisher = self.create_publisher(
            JointState,
            '/joint_command', 
            10
        )
        
        # Initialization (Sends P command, pauses, then STARTS the timer)
        self._set_initial_position()

        # Subscriber (Refactored to only store data)
        self.state_subscription = self.create_subscription(
            JointState,
            '/joint_states', # Topic published by Isaac Sim
            self.joint_state_callback, # This callback is now simple storage
            10
        )
        
        self.get_logger().info('Initialization complete. LQR control is now active.')


    def _load_koopman_model(self):
        self.get_logger().info('Loading Koopman Model and Gains...')
        pkg_share_dir = get_package_share_directory('koopman_controller_pkg')

        # --- Load Model Weights (.pth) ---
        subsuffix = 'With_reg'
        model_file_name = subsuffix + ".pth"
        model_file_path = os.path.join(pkg_share_dir, 'data', model_file_name)
        
        dicts = torch.load(model_file_path, map_location=torch.device('cpu'))
        state_dict = dicts["model"]
        Elayer = dicts["layer"]
        Nkoopman = 30
        u_dim = 5

        # Extract matrices
        self.Ad = state_dict['lA.weight'].cpu().numpy()
        self.Bd = state_dict['lB.weight'].cpu().numpy()
        
        # --- Load LQR Gain Matrix (Kopt.mat) ---
        kopt_file_path = os.path.join(pkg_share_dir, 'data', 'Kopt.mat')
        kopt_data = loadmat(kopt_file_path)
        self.Kopt = kopt_data['Kopt'] 
        
        # --- NEW: Define the M
        self.NKoopman = Nkoopman 
        
        self.net = lka.Network(Elayer, Nkoopman, u_dim)
        self.net.load_state_dict(state_dict)
        self.net.cpu().double()

        # Extract matrices
        self.Ad = state_dict['lA.weight'].cpu().numpy()
        self.Bd = state_dict['lB.weight'].cpu().numpy()
        
        # --- Load LQR Gain Matrix (Kopt.mat) ---
        kopt_file_path = os.path.join(pkg_share_dir, 'data', 'Kopt.mat')
        kopt_data = loadmat(kopt_file_path)
        self.Kopt = kopt_data['Kopt'] 
        
        # --- NEW: Define the Model's Design Time Step ---
        self.ts = 0.02 


    def _load_desired_trajectory(self):
        self.get_logger().info('Loading Desired Trajectory (Joint States)...')
        pkg_share_dir = get_package_share_directory('koopman_controller_pkg')
        
        traj_file_path = os.path.join(pkg_share_dir, 'data', 'trajectories.mat')
        mat_data = loadmat(traj_file_path)
        
        self.desired_states = mat_data['desired_states']
        self.get_logger().info(f"Loaded trajectory with {self.desired_states.shape[0]} steps.")
        

    def _koopman_lift(self, state):
        """ Implements Psi_o(s, net) function. """
        s_tensor = torch.DoubleTensor(state).unsqueeze(0)
        ds = self.net.encode(s_tensor).detach().cpu().numpy().flatten()
        psi = np.zeros([self.NKoopman, 1]) 
        psi[:, 0] = ds 
        return psi


    # --- REFACTORED: This now only saves the data ---
    def joint_state_callback(self, msg):
        """
        Callback executed upon receiving a new joint state message. 
        It only stores the data for the fixed-rate control loop to use.
        """
        self.latest_state_msg = msg


    # --- NEW FUNCTION: Fixed-Rate Control Loop ---
    def control_loop(self):
        """
        Fixed-rate control loop executing the Koopman LQR law at self.ts (0.02s).
        This contains the logic previously in joint_state_callback.
        """
        if self.latest_state_msg is None:
            self.get_logger().warn('Control loop skipped: No joint state data received yet.')
            return

        msg = self.latest_state_msg # Use the stored latest message
        
        # 1. Extract state
        q_k = np.array(msg.position[:self.N_JOINTS])
        dq_k = np.array(msg.velocity[:self.N_JOINTS])
        x_k = np.concatenate((q_k, dq_k)) 

        # 2. Trajectory Indexing
        ref_idx = min(self.current_timestep + 1, self.desired_states.shape[0] - 1)
        x_des_next = self.desired_states[ref_idx, :]

        # 3. Koopman Lift and LQR Calculation
        psi_k = self._koopman_lift(x_k) 
        psi_des_next = self._koopman_lift(x_des_next) 

        error_lifted = psi_k - psi_des_next
        u_k = - np.dot(self.Kopt, error_lifted)
        velocity_command = u_k.flatten()[:self.N_JOINTS]

        # 4. Publish Command
        vel_command_msg = JointState()
        vel_command_msg.header.stamp = self.get_clock().now().to_msg() 
        vel_command_msg.name = self.JOINT_NAMES
        vel_command_msg.velocity = velocity_command.tolist() 

        self.velocity_publisher.publish(vel_command_msg) 

        # 5. Increment Timestep
        self.current_timestep += 1
        
        # Log for debugging (optional)
        if self.current_timestep % 50 == 0:
            self.get_logger().info(f'Step {self.current_timestep}: Applied Velocities: {velocity_command}')

    
    def _set_initial_position(self):
        """
        Sends a one-time position command to the robot to jump to the start, 
        pauses for settling, and then starts the LQR timer.
        """
        if self.desired_states.size == 0:
            self.get_logger().warn('Desired trajectory not loaded. Skipping initial setpoint.')
            return

        # Extract the desired initial joint positions (q)
        initial_q_des = self.desired_states[0, 0:self.N_JOINTS]
        
        # Create and publish the position command
        pos_command_msg = JointState()
        pos_command_msg.header.stamp = self.get_clock().now().to_msg() 
        pos_command_msg.name = self.JOINT_NAMES
        pos_command_msg.position = initial_q_des.tolist() 
        
        self.get_logger().info(f'Sending initial position command: {initial_q_des}')
        self.position_publisher.publish(pos_command_msg)
        
        # Wait for robot to settle
        self.get_logger().info("Pausing for 0.5s to let Isaac Sim process the initial position command...")
        import time
        time.sleep(0.5)
        
        # CRITICAL: Enable the fixed-rate LQR control loop ONLY after settling
        self.timer.reset()
        self.get_logger().info("Robot settled. Enabling 50 Hz LQR control timer.")

def main(args=None):
    rclpy.init(args=args)
    controller_node = KoopmanLQRController()
    
    try:
        rclpy.spin(controller_node)
    except KeyboardInterrupt:
        pass
    finally:
        controller_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
