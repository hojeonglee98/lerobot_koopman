import rclpy
from rclpy.node import Node
import numpy as np
import torch
import torch.nn as nn # For loading the network
from scipy.io import loadmat
import os
from ament_index_python.packages import get_package_share_directory
# Using JointState for both state subscription (input) and command publication (output)
from sensor_msgs.msg import JointState      

# Assuming this module is installed in your package directory
from koopman_controller_pkg import Learn_Koopman_with_Klinear_Lerobot as lka


class KoopmanLQRController(Node):
    """
    ROS 2 Node implementing the Koopman-Affine LQR controller.
    Publishes velocity commands via sensor_msgs/JointState.
    """
    def __init__(self):
        super().__init__('koopman_lqr_controller')
        self.get_logger().info('Koopman LQR Node Initializing...')

        # --- 1. Model Loading ---
        self._load_koopman_model()

        # --- 2. Trajectory Data ---
        self._load_desired_trajectory()
        self.current_timestep = 0 # Simple counter for tracking trajectory reference
        self.N_JOINTS = 5

        # Define the names of the 5 controlled joints (MUST match your URDF)
        self.JOINT_NAMES = [
            'shoulder_pan', 
            'shoulder_lift', 
            'elbow_flex',
            'wrist_flex', 
            'wrist_roll'
        ]

        # --- 3. ROS 2 Communication Setup ---
        # Subscriber for the robot's current joint state (our observation x_k)
        self.state_subscription = self.create_subscription(
            JointState,
            '/joint_states', # Topic published by Isaac Sim
            self.joint_state_callback,
            10
        )

        self.position_publisher = self.create_publisher(
            JointState,
            '/joint_command', # Isaac Sim can take position or velocity on this topic
            1
        )

        self.velocity_publisher = self.create_publisher(
            JointState,
            '/joint_command', # Ensure this matches the topic subscribed to by Isaac Sim
            10
        )
        self._set_initial_position()
        
        self.get_logger().info('Initialization complete. Waiting for joint states.')


    def _load_koopman_model(self):
        self.get_logger().info('Loading Koopman Model and Gains...')
        pkg_share_dir = get_package_share_directory('koopman_controller_pkg')

        # --- Load Model Weights (.pth) ---
        subsuffix = 'With_reg'
        model_file_name = subsuffix + ".pth"
        model_file_path = os.path.join(pkg_share_dir, 'data', model_file_name)
        
        # Load model and set NKoopman based on network output (30 encoded features)
        dicts = torch.load(model_file_path, map_location=torch.device('cpu'))
        state_dict = dicts["model"]
        Elayer = dicts["layer"]

        # CRITICAL: Nkoopman is the size of the encoded state (30) 
        # since the lifted state is defined as Psi = [ds] only.
        # This size (30) must match the network's output size.
        Nkoopman = 30
        u_dim = 5
        self.NKoopman = Nkoopman 
        
        self.net = lka.Network(Elayer, Nkoopman, u_dim)
        self.net.load_state_dict(state_dict)
        self.net.cpu().double()

        # Extract matrices
        self.Ad = state_dict['lA.weight'].cpu().numpy()
        self.Bd = state_dict['lB.weight'].cpu().numpy()
        
        # --- Load LQR Gain Matrix (Kopt.mat) ---
        kopt_file_path = os.path.join(pkg_share_dir, 'data', 'Kopt.mat')
        kopt_data = loadmat(kopt_file_path)
        # CRITICAL FIX: Extract the matrix array from the dictionary
        self.Kopt = kopt_data['Kopt'] 
        
        self.ts = 0.02 # Discrete time step


    def _load_desired_trajectory(self):
        self.get_logger().info('Loading Desired Trajectory (Joint States)...')
        pkg_share_dir = get_package_share_directory('koopman_controller_pkg')
        
        traj_file_path = os.path.join(pkg_share_dir, 'data', 'trajectories.mat')
        mat_data = loadmat(traj_file_path)
        
        # CRITICAL FIX: Extract the array from the dictionary
        self.desired_states = mat_data['desired_states']
        self.get_logger().info(f"Loaded trajectory with {self.desired_states.shape[0]} steps.")
        

    def _koopman_lift(self, state):
        """
        Implements Psi_o(s, net) function from the notebook: Psi = encoded_features (ds).
        """
        # Ensure state is a torch tensor
        s_tensor = torch.DoubleTensor(state).unsqueeze(0)
        # ds shape is (1, 30) -> flatten to (30,)
        ds = self.net.encode(s_tensor).detach().cpu().numpy().flatten()
        
        # Create psi array with shape (NKoopman, 1) = (30, 1)
        psi = np.zeros([self.NKoopman, 1]) 
        
        # Assign ds (30,) to the first column of psi (30, 1)
        psi[:, 0] = ds 
        
        return psi


    def joint_state_callback(self, msg):
        """
        Callback function executed upon receiving a new joint state message.
        """

        q_k = np.array(msg.position[:self.N_JOINTS])
        dq_k = np.array(msg.velocity[:self.N_JOINTS])
        x_k = np.concatenate((q_k, dq_k)) 

        ref_idx = min(self.current_timestep + 1, self.desired_states.shape[0] - 1)
        x_des_next = self.desired_states[ref_idx, :]

        psi_k = self._koopman_lift(x_k) 
        psi_des_next = self._koopman_lift(x_des_next) 


        error_lifted = psi_k - psi_des_next
        u_k = - np.dot(self.Kopt, error_lifted)

        velocity_command = u_k.flatten()[:self.N_JOINTS]

        vel_command_msg = JointState()

        vel_command_msg.header.stamp = self.get_clock().now().to_msg() 
        vel_command_msg.name = self.JOINT_NAMES
        vel_command_msg.velocity = velocity_command.tolist() 

        self.velocity_publisher.publish(vel_command_msg) 

        # 6. Increment Timestep
        self.current_timestep += 1
        
        # Log for debugging (optional)
        if self.current_timestep % 50 == 0:
            self.get_logger().info(f'Step {self.current_timestep}: Applied Velocities: {velocity_command}')

def _set_initial_position(self):
        """
        Sends a one-time position command to the robot to jump to the start
        of the desired trajectory.
        """
        if self.desired_states.size == 0:
            self.get_logger().warn('Desired trajectory not loaded. Skipping initial setpoint.')
            return

        # Extract the desired initial joint positions (q)
        initial_q_des = self.desired_states[0, 0:self.N_JOINTS]
        
        # Create the JointState message
        pos_command_msg = JointState()
        pos_command_msg.header.stamp = self.get_clock().now().to_msg() 
        pos_command_msg.name = self.JOINT_NAMES
        pos_command_msg.position = initial_q_des.tolist() 
        
        # Publish the command
        self.get_logger().info(f'Sending initial position command: {initial_q_des}')
        self.position_publisher.publish(pos_command_msg)
        
        # Give the simulation time to process the command.
        # This is a common pattern for "one-shot" setup in ROS control, 
        # as ROS messages are asynchronous.
        # A 0.5s pause should be enough for Isaac Sim to receive and execute.
        self.get_logger().info("Pausing for 0.5s to let Isaac Sim process the initial position command...")
        import time
        time.sleep(0.5)

def main(args=None):
    rclpy.init(args=args)
    controller_node = KoopmanLQRController()
    
    try:
        rclpy.spin(controller_node)
    except KeyboardInterrupt:
        pass
    finally:
        controller_node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()